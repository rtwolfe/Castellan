# clinical-intake-agent — Quick Start

## 1. Prerequisites

```bash
pip install castellan anthropic
```

## 2. Set Environment Variables

```bash
export ANTHROPIC_API_KEY=your-anthropic-api-key
```

## 3. Run Your First Message

```bash
castellan run agent.yaml -m "Hi, I need to see a doctor."
```

## 4. Run the Test Suite

```bash
castellan test agent.yaml
```

This agent has 5 test cases defined.

## 5. Deploy to Production

```bash
# Docker container
castellan export docker agent.yaml -o ./deploy

# Or run as a server
castellan serve agent.yaml --port 8000
```

---

## Agent Details

| Property | Value |
|----------|-------|
| **Name** | clinical-intake-agent |
| **Version** | 1.0.0 |
| **Model** | claude-sonnet-4-20250514 |
| **Provider** | anthropic |
| **Tools** | verify_patient_identity, retrieve_patient_record, assess_urgency, schedule_appointment, trigger_emergency_escalation, create_intake_record |
| **Quality Gates** | 4 |
| **Test Cases** | 5 |
| **Regulations** | HIPAA |
| **EU AI Act Tier** | High Risk |
| **Governance Score** | 100 / 100 |

## Package Contents

| File | Description |
|------|-------------|
| `index.html` | Interactive handoff dashboard — six tabs, no server required |
| `agent-card.html` | Shareable one-page executive brief |
| `compliance_manifest.json` | OWASP Agentic Top 10, EU AI Act, NIST AI RMF, governance score |
| `agent_manifest.json` | Agent identity, tools, constitutional SHA256 fingerprint |
| `ai_sbom.json` | AI Software Bill of Materials (CycloneDX 1.5) |
| `redteam_tests.py` | 6 adversarial test scenarios — executable immediately |
| `agent.yaml` | Compiled agent specification — version-controlled source of truth |
| `API.md` | Integration reference — endpoints, auth, rate limits, examples |
| `QUICKSTART.md` | This file |
