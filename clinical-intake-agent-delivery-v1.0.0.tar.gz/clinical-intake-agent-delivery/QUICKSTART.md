# clinical-intake-agent — Quick Start

## 1. Prerequisites

```bash
pip install castellan anthropic
```

## 2. Set Environment Variables

```bash
export ANTHROPIC_API_KEY=your-anthropic-api-key
```

## 3. Run Your First Message

```bash
castellan run agent.yaml -m "Hi, I need to see a doctor."
```

## 4. Run the Test Suite

```bash
castellan test agent.yaml
```

This agent has 5 test cases defined.

## 5. Deploy to Production

```bash
# Docker container
castellan export docker agent.yaml -o ./deploy

# Or run as a server
castellan serve agent.yaml --port 8000
```

---

## Agent Details

| Property | Value |
|----------|-------|
| **Name** | clinical-intake-agent |
| **Version** | 1.0.0 |
| **Model** | claude-sonnet-4-20250514 |
| **Provider** | anthropic |
| **Tools** | verify_patient_identity, retrieve_patient_record, assess_urgency, schedule_appointment, trigger_emergency_escalation, and 1 more |
| **Quality Gates** | 4 |
| **Test Cases** | 5 |

## Package Contents

| File | Description |
|------|-------------|
| `index.html` | Interactive handoff experience |
| `agent-card.html` | Shareable agent identity card |
| `compliance_manifest.json` | OWASP & governance compliance manifest |
| `agent_manifest.json` | Agent identity & capability fingerprint |
| `ai_sbom.json` | AI Software Bill of Materials (CycloneDX 1.5) |
| `redteam_tests.py` | Adversarial test scaffold (if enabled) |
| `agent.yaml` | The compiled agent specification |
| `API.md` | API reference documentation |
| `QUICKSTART.md` | This file |
