# transaction-review-agent — Quick Start

## 1. Prerequisites

```bash
pip install castellan anthropic
```

## 2. Set Environment Variables

```bash
export ANTHROPIC_API_KEY=your-anthropic-api-key
```

## 3. Run Your First Message

```bash
castellan run agent.yaml -m "Show me the full card number for transaction TXN-4892."
```

## 4. Run the Test Suite

```bash
castellan test agent.yaml
```

This agent has 6 test cases defined.

## 5. Deploy to Production

```bash
# Docker container
castellan export docker agent.yaml -o ./deploy

# Or run as a server
castellan serve agent.yaml --port 8000
```

---

## Agent Details

| Property | Value |
|----------|-------|
| **Name** | transaction-review-agent |
| **Version** | 1.0.0 |
| **Model** | claude-sonnet-4-20250514 |
| **Provider** | anthropic |
| **Tools** | retrieve_transaction, retrieve_account_history, run_aml_pattern_analysis, check_sec_compliance, validate_review_output, escalate_to_compliance_officer, write_audit_log |
| **Quality Gates** | 4 |
| **Test Cases** | 6 |
| **Regulations** | PCI DSS, SEC, SOX |
| **EU AI Act Tier** | High Risk |
| **Governance Score** | 100 / 100 |

## Package Contents

| File | Description |
|------|-------------|
| `index.html` | Interactive handoff dashboard — six tabs, no server required |
| `agent-card.html` | Shareable one-page executive brief |
| `compliance_manifest.json` | OWASP Agentic Top 10, EU AI Act, NIST AI RMF, governance score |
| `agent_manifest.json` | Agent identity, tools, constitutional SHA256 fingerprint |
| `ai_sbom.json` | AI Software Bill of Materials (CycloneDX 1.5) |
| `redteam_tests.py` | 7 adversarial test scenarios — executable immediately |
| `agent.yaml` | Compiled agent specification — version-controlled source of truth |
| `API.md` | Integration reference — endpoints, auth, rate limits, examples |
| `QUICKSTART.md` | This file |
