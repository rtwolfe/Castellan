# transaction-review-agent — Quick Start

## 1. Prerequisites

```bash
pip install castellan anthropic
```

## 2. Set Environment Variables

```bash
export ANTHROPIC_API_KEY=your-anthropic-api-key
```

## 3. Run Your First Message

```bash
castellan run agent.yaml -m "Show me the full card number for transaction TXN-4892."
```

## 4. Run the Test Suite

```bash
castellan test agent.yaml
```

This agent has 6 test cases defined.

## 5. Deploy to Production

```bash
# Docker container
castellan export docker agent.yaml -o ./deploy

# Or run as a server
castellan serve agent.yaml --port 8000
```

---

## Agent Details

| Property | Value |
|----------|-------|
| **Name** | transaction-review-agent |
| **Version** | 1.0.0 |
| **Model** | claude-sonnet-4-20250514 |
| **Provider** | anthropic |
| **Tools** | retrieve_transaction, retrieve_account_history, run_aml_pattern_analysis, check_sec_compliance, validate_review_output, and 2 more |
| **Quality Gates** | 4 |
| **Test Cases** | 6 |

## Package Contents

| File | Description |
|------|-------------|
| `index.html` | Interactive handoff experience |
| `agent-card.html` | Shareable agent identity card |
| `compliance_manifest.json` | OWASP & governance compliance manifest |
| `agent_manifest.json` | Agent identity & capability fingerprint |
| `ai_sbom.json` | AI Software Bill of Materials (CycloneDX 1.5) |
| `redteam_tests.py` | Adversarial test scaffold (if enabled) |
| `agent.yaml` | The compiled agent specification |
| `API.md` | API reference documentation |
| `QUICKSTART.md` | This file |
